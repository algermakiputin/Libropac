<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class notices extends Model
{
    protected $fillable = ['title','content'];
}
