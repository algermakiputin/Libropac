	<script src="<?php echo e(url('assets/js/plugins.js')); ?>"></script>
    	<script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>"></script>
    	<script src="<?php echo e(url('assets/js/jquery.prettyPhoto.js')); ?>"></script>   
    	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCWDPCiH080dNCTYC-uprmLOn2mt2BMSUk&amp;sensor=true"></script>
    	<script type="text/javascript" src="https://cdn.datatables.net/v/bs/dt-1.10.18/datatables.min.js"></script> 
    	<script src="<?php echo e(url('assets/js/init.js')); ?>"></script>
    	<script src="<?php echo e(url('dashboard/js/plugins/parsley.js')); ?>"></script>
    	<script src="<?php echo e(url('assets/js/jquery-loading.js')); ?>"></script>
    	<script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>
</body>
</html>