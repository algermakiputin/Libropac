<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Library System - Holy Child College of Davao</title>

	<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
	<div id="preloader"></div>
	<?php echo $__env->make('template.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->yieldContent('content'); ?>

	<div id="footer-wrapper"  >
	    <footer id="footer" class="">
	        <div class="container">
	            <div class="row">
	                <div class="col-sm-8">
	                    &copy; 2018 Holy Child College of Davao Library System. Developed By: <a href="https://algermakiputin.com">Alger Makiputin</a>
	                </div>
	                <div class="col-sm-4">
	                    <ul class="pull-right">
	                        <li><a id="gototop" class="gototop" href="#"><i class="fa fa-chevron-up"></i></a></li><!--#gototop-->
	                    </ul>
	                </div>
	            </div>
	        </div>
	    </footer><!--/#footer-->
	</div>
	<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
</body>
</html>