 <?php $__env->startSection('content'); ?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-undo"></i> Lost Resource</h1>
            <p>Library Holdings</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">Lost Resource</li> 
        </ul>
    </div>
    <div class="tile">
        <form method="POST" id="return_form" action="<?php echo e(url('admin/lost/update')); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('patch'); ?>
          <div class="row">
              <div class="offset-md-3 col-md-6 ">
                  <?php if(Session::has('success')): ?>
                  <div class="alert alert-success">
                       <?php echo e(Session::get('success')); ?>

                    </div>
                  <?php endif; ?>
                  <?php if(Session::has('error')): ?>
                  <div class="alert alert-danger">
                       <?php echo e(Session::get('error')); ?>

                    </div>
                  <?php endif; ?>
                  <h3 class="tile-title">Process Lost Resources</h3>
                  <p>When barrowers lost the resource that they borrow. Enter transaction ID to record lost resource.</p>
              </div>
              <div class="offset-md-3 col-md-6">

                  <div class="tile-body">
                      <div class="form-horizontal">
                          <div class="form-group row">
                              <label class="control-label col-md-3">Transaction ID</label>
                              <div class="col-md-8">
                                  <input class="form-control" required="required" type="text" placeholder="Transaction ID" name="transaction_id">
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="tile-footer">
                    
                      <a class="btn btn-secondary cancel" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a> &nbsp;&nbsp;&nbsp;
                      <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Submit</button>
                     

                  </div>

              </div>
               
              <div class="col-md-12 text-right">
                  
              </div>
              <div class="clearix"></div>

          </div>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard-master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>