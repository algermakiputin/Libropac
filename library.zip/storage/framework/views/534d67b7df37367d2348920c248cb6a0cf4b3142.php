<footer style="padding: 15px 25px 0 0;">
    <p class="text-right text-red">
        &copy; Copyright 2018, Library Management System  Developed By: <a href="https://algermakiputin.com">Alger Makiputin</a>
    </p>
</footer>
    <script src="<?php echo e(url('dashboard/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(url('dashboard/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(url('dashboard/js/bootstrap.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
    <script src="<?php echo e(url('dashboard/js/main.js')); ?>"></script>
    <script src="<?php echo e(url('dashboard/js/plugins/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('dashboard/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo e(url('dashboard/js/plugins/pace.min.js')); ?>"></script>
    <script src="<?php echo e(url('dashboard/js/plugins/bootstrap-notify.min.js')); ?>"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(url('assets/js/jquery-loading.js')); ?>"></script>
    <script src="<?php echo e(url('dashboard/js/plugins/parsley.js')); ?>"></script>
    <script src="<?php echo e(url('dashboard/js/custom.js')); ?>"></script>
    <!-- Page specific javascripts-->
   
 