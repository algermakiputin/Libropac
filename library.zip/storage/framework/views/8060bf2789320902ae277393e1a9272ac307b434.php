
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs/dt-1.10.18/datatables.min.css"/>
    <link href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/css/pe-icons.cs')); ?>s" rel="stylesheet">
    <link href="<?php echo e(url('assets/css/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/css/style.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(url('assets/js/jquery.js')); ?>"></script>
    
 
    

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon" sizes="144x144" href="images/ico/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/ico/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/ico/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" href="images/ico/apple-touch-icon-57x57.png">

    



