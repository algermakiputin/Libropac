<!DOCTYPE html>
<html>
<head>
	<title></title>

	<?php echo $__env->make('dashboard.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="app sidebar-mini rtl">
	<?php echo $__env->make('dashboard.template.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('dashboard.template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 	<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('dashboard.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>