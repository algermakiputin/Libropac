<?php $__env->startSection('content'); ?>
<!-- <div id="preloader"></div> -->
<script type="text/javascript">
    jQuery(document).ready(function($){
    'use strict';
        jQuery('body').backstretch([
            "<?php echo e(url('assets/images/header/1.jpg')); ?>",
            "<?php echo e(url('assets/images/header/2.jpg')); ?>",
            "<?php echo e(url('assets/images/header/3.jpg')); ?>",
            "<?php echo e(url('assets/images/header/4.jpg')); ?>",
            "<?php echo e(url('assets/images/header/7.jpg')); ?>",
            "<?php echo e(url('assets/images/header/8.jpg')); ?>",
            "<?php echo e(url('assets/images/header/9.jpg')); ?>"
        ], {duration: 5000, fade: 700, centeredY: true });

       
    });
</script>

<section id="main-slider" class="no-margin">
    <div class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="item active">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="carousel-content text-center">
                                <span class="home-icon  pe-7s-notebook bounce-in"></span>
                                <h2 class="boxed animation animated-item-1 fade-down">Holy Child College of Davao</h2> 
                                <div>
                                    <p class="boxed animation animated-item-2 fade-up">Online library Management System</p>
                                <br>
                                </div>
                                <a class="btn btn-md animation bounce-in" href="#services">Learn More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.item-->
        </div><!--/.carousel-inner-->
    </div><!--/.carousel-->
</section><!--/#main-slider-->

<div id="content-wrapper">
    <section id="services" class="white">
        <div class="container">
            <div class="gap"></div> 
            <div class="row">
                <div class="col-md-12">
                    <div class="center gap fade-down section-heading">
                        <h2 class="main-title">Notice</h2>
                        <hr>
                        <p>News and updates from the library</p>
                    </div>                
                </div>
            </div>

            <div class="row">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="col-md-6 col-sm-12">
                        <div class="service-block">
                            <div class="pull-left bounce-in no-display animated bounceIn appear">
                                <i class="fa fa-bell fa fa-md"></i>
                            </div>
                            <div class="media-body fade-up">
                                <h3 class="media-heading"><?php echo e($n->title); ?></h3>
                                <p><?php echo e($n->content); ?></p>
                            </div>
                        </div>
                    </div> 
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div><!--/.row-->
           
             
        </div>
        <div class="gap"></div>
   
    </section>


    <section id="single-quote" class="divider-section">                             
        <div class="container">
            <div class="gap"></div> 
            <div class="row">
                <div class="col-md-12">
                    <div class="center gap fade-down section-heading">
                        <h2 class="main-title">Meet our Librarians</h2>
                        <hr>
                         
                    </div>                
                </div>
            </div>
            <div class="row">                        
                <div class='col-md-offset-2 col-md-8 fade-up'>
                    <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                        <div class="carousel-inner">
                            <div class="item active">
                          
                                    <div class="row">
                                        <div class="col-sm-3 text-center">
                                            <img class="img-responsive" src="images/team/team01.jpg" style="width: 100px;height:100px;">
                                        </div>
                                        <div class="col-sm-9">
                                            <h4>Mr. John Doe</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo 
                                            </p>
                                            <small>-College Librarian</small>
                                        </div>
                                    </div>
                              
                            </div>                                  
                        </div>                                     
                    </div> 
                </div>
            </div>
            <div class="gap"></div>
        </div>
    </section>

    <section id="about-us" class="white">
        <div class="container">
            <div class="gap"></div>
            <div class="row">
                <div class="col-md-12">
                    <div class="center gap fade-down section-heading">
                        <h2 class="main-title">A Little About Our Library Department</h2>
                        <hr>
                        <p>Thus, the standard library will serve both a tool and as a teacher</p>
                    </div>                
                </div>
            </div>
            <div class="row">
                <div class="col-md-10 col-md-offset-1 fade-up">
                    <?php echo e($history[0]->content); ?>

                </div>
                <div class="col-md-4 fade-up">

                </div>
            </div>
 
            <div class="gap"></div>
   
            <div class="gap"></div>   
        </div>      
    </section>
 

  
 
</section>

 

 
 
 
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>