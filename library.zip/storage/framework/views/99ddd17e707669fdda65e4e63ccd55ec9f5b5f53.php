<header class="navbar navbar-inverse navbar-fixed-top " role="banner">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><h1><span class="pe-7s-notebook bounce-in no-display animated bounceIn appear"></span> Library System</h1></a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
               
                <li><a href="<?php echo e(url('/books')); ?>">Books</a></li>
                <li><a href="<?php echo e(url('/multimedia')); ?>">Multimedia Resources</a></li>
                <li><a href="<?php echo e(url('/ask')); ?>">ASK LIBRARIAN</a></li>
                <li><a href="<?php echo e(url('/register')); ?>">REGISTER</a></li>
              
                
               
            </ul>
        </div>
    </div>
</header>